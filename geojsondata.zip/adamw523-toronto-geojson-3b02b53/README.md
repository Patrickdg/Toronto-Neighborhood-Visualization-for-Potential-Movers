toronto-geojson
===============

GeoJSON of Toronto Neighbourhoods

Examle: [http://adamw523.github.com/toronto-geojson/](http://adamw523.github.com/toronto-geojson/)

[Shapefile to GeoJSON](http://blog.adamw523.com/shapefile-to-geojson/)
